#!/usr/bin/env python
#-*- coding:UTF-8 -*-
#########################################################################
# File Name: doc_ad_flask.py
# Author: NLP_Team_zhaozhenyu
# Mail: zhaozhenyu@corp.netease.com
# Created Time: 09:56:49 2018-09-05
#########################################################################
import sys
from flask import Flask, jsonify,request
import advertise as ad
import pickle
import logging
import traceback
import configparser
import logger
from datetime import datetime
from gevent.pywsgi import WSGIServer

#load config
cf = configparser.ConfigParser()
cf.read('./config.ini')
#load model
tp_model = pickle.load(open(cf.get('model','tp_model'),'rb'))
seg_model = pickle.load(open(cf.get('model','seg_model'),'rb'))
#load feature dict
tp_fea = ad.getdic(cf.get('feadict','tp_fea'))
seg_fea = ad.getdic(cf.get('feadict','seg_fea'))
print(len(tp_fea))
print(len(seg_fea))
#log path
service_logger = logger.getLoggers('serviceLog', logging.INFO, cf.get('log','log_service_path'))
error_logger = logger.getLoggers('errorLog',logging.INFO, cf.get('log','log_error_path'))
print('config complete')
app = Flask(__name__)

@app.route("/api/v0/docadvertise",methods=['POST'])
def index():
    dict_cur = {}
    dict_res = {}
    time_begin = datetime.now()
    try:
        #get param
        docid = request.form.get('docid')
        title = request.form.get('title')
        content = request.form.get('content')
        category = request.form.get('category')
        sourcelevel = request.form.get('sourcelevel')
        #get res
        dict_cur = ad.advertise_detect(docid, title, content, category, sourcelevel, tp_fea, seg_fea, tp_model, seg_model)
        time_end = datetime.now()
        line = 'start:\t'+str(time_begin)+'\ttimeconsume:\t'+str(time_end-time_begin)+'\t'
        for k in dict_cur:
            line = line+str(k)+'\t'+str(dict_cur[k])+'\t'
        service_logger.info('\t'.join([docid,title,category,sourcelevel,line]))
        dict_res['predict_y'] = dict_cur['predict_y']
        dict_res['status'] = dict_cur['status']
        return jsonify(dict_res)
    except Exception as e:
        time_end = datetime.now()
        msg = str(traceback.format_exc())
        dict_res['predict_y'] = 0
        dict_res['status'] = 0
        line = 'error!!!\tstart:\t'+str(time_begin)+'\ttimeconsume:\t'+str(time_end-time_begin)+'\t'
        error_logger.info(str(request.form)+str(msg))
        return jsonify(dict_res)

@app.route("/ndp/status",methods=['GET'])
def index_health():
    return "'Cangjie - AI - NLP - advertise\n'"


if __name__=='__main__':
    WSGIServer(('localhost',9003),app).serve_forever()
