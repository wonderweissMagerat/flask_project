#!/bin/bash
#########################################################################
# File Name: stop.sh
# Author: NLP_Team_zhaozhenyu
# Mail: zhaozhenyu@corp.netease.com
# Created Time: 15:56:49 2018-09-05
#########################################################################
lsof -i:9001 | awk 'NR>1{print $2}' | xargs kill -9
