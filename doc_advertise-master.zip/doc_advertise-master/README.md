## 软文硬广服务文档
- 0.1版本

## 接口地址
- http://localhost:9003/api/v0/docadvertise（本地）


- http://cangjie-bj.service.163.org/api/v0/docadvertise(域名)


## 测试接口地址
机房ip：
- http://10.102.156.98:9003/api/v0/docadvertise

- http://10.102.156.99 :9003/api/v0/docadvertise

私有ip：
- http://10.112.96.61:9003/api/v0/docadvertise

- http://10.112.96.62:9003/api/v0/docadvertise


## 请求方式
- POST

## 请求参数
- docid(必须，base.docid)  string
- title(必须，base.title)  string
- content(必须,extra.content)   string
- category(必须,base.category)   string
- sourcelevel(必须,base.sourceLevel)  int


## 返回结果为json字符串,value值均为int型
{
    "predict_y": 1,
    "status": 0,
}

- 说明：predict_y为广告结果，1为广告删除，0为正常 int型；status为调用状态：1为正常，0为出错


## 依赖：
- Anaconda3-5.2.0-Linux-x86_64
- jieba
- pyspellchecker
- pickle
- flask
- configparser
- gevent
- gunicorn
- msgpack

