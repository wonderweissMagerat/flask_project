#!/usr/bin/env pythonuthor: bjluoyahui@corp.netease.com
# Created Time : Tue 29 May 2018 03:27:09 PM CST
# File Name: logger.py
# Copyright: 2018 NetEase. All rights reserved.
# Description: log file."""
import logging
import logging.handlers
import os

current_path = os.path.abspath(__file__)
father_path = os.path.abspath(os.path.dirname(current_path) + os.path.sep + ".")

def getLoggers(loggerName , loggerLevel , loggerLocation ):
    logger = logging.getLogger(loggerName)
    logger.setLevel(loggerLevel)
    format="%(asctime)s - %(levelname)s : %(message)s"
    formater = logging.Formatter(format)
    handler = logging.handlers.TimedRotatingFileHandler(loggerLocation, "D", 1, 0)
    handler.suffix = "%Y%m%d.%H:%M:%S"
    handler.setFormatter(formater)
    logger.addHandler(handler)
    return logger

#--------------- Service log setting start ---------------------#
# 服务日志
#logService = getLoggers('logService' , logging.INFO , father_path + '/log/service.log')
#logFormatError = getLoggers('logFormatError', logging.INFO, father_path + '/log/formaterror.log')

