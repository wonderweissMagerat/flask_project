#!/bin/bash
#########################################################################
# File Name: start.sh
# Author: NLP_Team_zhaozhenyu
# Mail: zhaozhenyu@corp.netease.com
# Created Time: 15:57:52 2018-09-05
#########################################################################
/home/appops/anaconda3/bin/gunicorn -w 4 -b 0.0.0.0:9001 doc_ad_flask:app
