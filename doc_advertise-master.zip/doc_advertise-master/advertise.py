#!/usr/bin/env python
#-*- coding:UTF-8 -*-
#########################################################################
# File Name: advertise.py
# Author: NLP_Team_zhaozhenyu
# Mail: zhaozhenyu@corp.netease.com
# Created Time: 19:39:29 2018-09-03
#########################################################################
import sys
import jieba
import re
from spellchecker import SpellChecker
spell=SpellChecker()

wechat_re=r'[a-zA-Z\d_]{6,}'
def check_wechat(word):
    if len(re.findall(wechat_re,word))!=0 and len(spell.known([word]))==0:
        return 'WEXIN'
    else:
        return word

html_re=r'</?\w+[^>]*>'

def map_fea(word_list,feadict):
    res=[0]*len(feadict)
    for i in word_list:
        if i in feadict:
            res[feadict[i]]=1
    #res = map(lambda x:feadict[x] if x in word_list else 0,list(feadict.keys()))
    return res

def content_fea_ext(content_word,tp_fea):
    res_fea = []
    cur_content = content_word
    for i in range(len(cur_content)):
        #check weixin
        word = check_wechat(cur_content[i])
        cur_content[i] = word
    res_fea = map_fea(cur_content,tp_fea)
    return res_fea


#获取通篇特征
def get_tp_fea(title,content,cur_fea,tp_fea):
    res_fea = []
    res_fea = content_fea_ext(content,tp_fea)
    res_fea.extend(cur_fea)
    return res_fea

def split_sentence(content_word):
    res_fea = []
    cur_fea = []
    punt = '.!?~。！？~'
    for word in content_word:
        if word not in punt:
            cur_fea.append(word)
        else:
            #排除连续标点导致每个标点一句的情况
            if len(cur_fea) < 1:
                continue
            cur_fea.append(word)
            res_fea.append(cur_fea)
            cur_fea = []
    #如果最后一句或者全文无句号
    if len(cur_fea) > 1:
        res_fea.append(cur_fea)
    return res_fea

def block_fea_ext(sentence_list,cur_fea,stc_fea):
    res_fea = []
    blocklist = []
    blocklist = sentence_list
    for stc in blocklist:
        s_fea=[]
        s_fea.extend(content_fea_ext(stc,stc_fea))
        s_fea.extend(cur_fea)
        res_fea.append(s_fea)
    return res_fea

def get_stc_fea(title,content,cur_fea,stc_fea):
    res_fea = []
    content_word = content
    sentence_list = split_sentence(content_word)
    res_fea = block_fea_ext(sentence_list,cur_fea,stc_fea)
    return res_fea,sentence_list


def get_seg_result(stc_x_list,sentence_list,stc_model):
    res_y=0
    y_list=[]
    line=''
    num = len(stc_x_list)
    if num < 3:
        for i in range(num):
            y=stc_model.predict_proba([stc_x_list[i]])[0][1]
            if y>0.7:
                res_y = 1
                line+=''.join(str(j) for j in sentence_list[i])
                return res_y,line
        return res_y,'3SEGNORMAL'
    else:
        for i in range(num//3,num*2//3):
            y = stc_model.predict_proba([stc_x_list[i]])[0][1]
            if y>0.7:
                res_y = 1
                line+=''.join(str(j) for j in sentence_list[i])
                return res_y,line
        return res_y,'SEGNORMAL'
                

total_cate=['艺术','动物','家居','房产','教育','体育','互联网','军事','情感','人文','财经','历史','旅游','时尚','科技','育儿','手机','数码','要闻','美食','社会','游戏','健康','娱乐']

def get_cate_fea(category):
    res=[]
    for i in total_cate:
        if i in category:
            res.append(1)
        else:
            res.append(0)
    return res

all_level=['1','2','3','4','5','6','7','8']
def get_level_fea(level):
    res=[]
    for i in all_level:
        if i == str(level):
            res.append(1)
        else:
            res.append(0)
    return res

#根据词表得到onehot
def getdic(path):
    file=open(path)
    diction={}
    count=0
    for lines in file:
        try:
            data=lines.strip().split('\t')
            diction[data[0]]=count
            count+=1
        except:
            continue
    return diction



#主模块
def advertise_detect(docid,title,content,category,level,tp_fea,stc_fea,tp_model,stc_model):
    res = {}
    if '汽车' in category:
        res['predict_y'] = 0
        res['status'] = 1
        res['segline'] = '类别为汽车，不处理'
        return res
    content_word = []
    content_word = list(jieba.cut(re.sub(html_re,'',content)))
    title_word = []
    #title_word = list(jieba.cut(title))

    category_fea = []
    category_fea = get_cate_fea(category)
    
    level_fea = []
    level_fea = get_level_fea(str(level))
    
    cur_fea = []
    cur_fea.extend(category_fea)
    cur_fea.extend(level_fea)
    
    sentence_list=[]
    #通篇特征提取
    tp_x = get_tp_fea(title_word,content_word,cur_fea,tp_fea)
    #通篇模型结果
    tp_y_pro = tp_model.predict_proba([tp_x])[0][1]
    if tp_y_pro > 0.6:
        res['predict_y']=1
    else:
        #句子特征提取：list
        stc_x_list, sentence_list = get_stc_fea(title_word,content_word,cur_fea,stc_fea)
        #句子模型结果，分句情况，每句结果
        seg_y,line=get_seg_result(stc_x_list,sentence_list,stc_model)
        #判断逻辑
        if seg_y==1:
            res['predict_y']=1
            res['segline']=str(line)
        else:
            res['predict_y']=0
        res['seg_y']=str(seg_y) 
    res['tp_res']=str(tp_y_pro)
    res['status']=1
    return res
    
