﻿#!/usr/bin/env python
#-*- coding:UTF-8 -*-
#########################################################################
# File Name: docVulgar_client.py
# Author: NLP_Team_zhaozhenyu
# Mail: zhaozhenyu@corp.netease.com
# Created Time: 21:19:57 2018-06-12
#########################################################################
import sys
import urllib
import urllib.request
import urllib.parse
import json
from datetime import datetime

testpath=sys.argv[1]
file=open(testpath)
paralist=[]
nparalist=[]
reslist=[]
count=0
linelist=[]
for lines in file:
    data=lines.strip().split('\t')
    linelist.append(lines.strip())
    id=data[1]
    title=data[3]
    content=data[4]
    category=data[6]
    sourcelevel=data[5]
    #doccate=data[5]
    params = {}
    params["title"] = title
    params["content"] = content
    params['category']=category
    params['sourcelevel']=sourcelevel
    #params['doccate']=doccate
    params['docid']=id
    nparalist.append(params)
    params = urllib.parse.urlencode(params)
    params=params.encode('utf-8')
    paralist.append(params)
url = 'http://localhost:9003/api/v0/docadvertise'
request = urllib.request.Request(url)
begin=datetime.now()
for para in paralist:
    res = json.loads(urllib.request.urlopen(request,para).read().decode('utf-8'))
    reslist.append(res)
end=datetime.now()

#print(str(end-begin))
for i in range(len(reslist)):
    if int(reslist[i]['predict_y'])==0:
        print(linelist[i])
    #print(str(i["predict_y"]))
    #print(nparalist[i]['docid']+'\t'+nparalist[i]['title']+'\t'+nparalist[i]['content']+'\t'+str(reslist[i]['predict_y']))
    #print(paralist[i])
    #print(i["res_cate"])
